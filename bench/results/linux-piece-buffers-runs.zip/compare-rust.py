# SPDX-FileCopyrightText: 2026 TorrPlay
# SPDX-License-Identifier: MIT

from contextlib import nullcontext
import csv
import json
from pathlib import Path
import signal
import socket
import subprocess
import sys
import tempfile
import time
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, build_opener

output = Path(__file__).resolve().parent
target, before, after, *existing = map(lambda value: Path(value).resolve(), sys.argv[1:])
bench = target / 'debug' / 'torrplay-bench'
with (output / 'source-revisions.tsv').open(newline='') as source:
    revisions = {row['build']: row['commit'] for row in csv.DictReader(source, delimiter='\t')}


def free_port():
    with socket.socket() as server:
        server.bind(('127.0.0.1', 0))
        return server.getsockname()[1]


def wait_for_listener(child, port):
    for _ in range(200):
        if child.poll() is not None:
            raise RuntimeError(f'local server exited with {child.returncode}')
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=.2):
                return
        except OSError:
            time.sleep(.1)
    raise RuntimeError(f'no local listener on port {port}')


def stop(child, sig):
    if child.poll() is None:
        child.send_signal(sig)
    try:
        child.wait(timeout=20)
    except subprocess.TimeoutExpired:
        child.kill()
        child.wait()


def verify_revision(binary, expected):
    port = free_port()
    with tempfile.TemporaryDirectory(prefix='rust-revision-', dir=target) as data:
        child = subprocess.Popen([binary, '--data-dir', data, '--listen', f'127.0.0.1:{port}',
                                  '--peer-port', '0', '--no-dht', '--log-level', 'warn'])
        try:
            wait_for_listener(child, port)
            opener = build_opener(ProxyHandler({}))
            with opener.open(f'http://127.0.0.1:{port}/api/v1/system', timeout=5) as response:
                reported = json.load(response).get('commit')
            # The application embeds an abbreviated commit and marks dirty builds.
            if not isinstance(reported, str) or len(reported) < 7 or not expected.startswith(reported):
                raise RuntimeError(f'{binary} reports revision {reported!r}, expected {expected}')
        finally:
            stop(child, signal.SIGTERM)


def verify_trial(result_path, expected_requests):
    with result_path.open() as raw:
        result = json.load(raw)
    if result['server']['exit_success'] is not True:
        raise RuntimeError(f'{result_path}: the server did not exit successfully')
    requests = result['run']['requests']
    if len(requests) != len(expected_requests):
        raise RuntimeError(f'{result_path}: expected {len(expected_requests)} requests, got {len(requests)}')
    for request, expected in zip(requests, expected_requests):
        for field in ('reader', 'fixture', 'file', 'range_start', 'range_end'):
            if request[field] != expected[field]:
                raise RuntimeError(
                    f"{result_path}: reader {expected['reader']} expected "
                    f"{field}={expected[field]!r}, got {request[field]!r}"
                )
        if (request['status'] != 206 or request['body_bytes'] != expected['consume_bytes']
                or request['error'] is not None):
            raise RuntimeError(
                f"{result_path}: reader {expected['reader']} expected HTTP 206 and "
                f"{expected['consume_bytes']} bytes, got HTTP {request['status']}, "
                f"{request['body_bytes']} bytes, error {request['error']!r}"
            )


runs = [('before', before), ('after', after)]
for label, binary in runs:
    verify_revision(binary, revisions[label])

trace = output / 'rust-comparison.jsonl'
events = [json.loads(line) for line in trace.read_text().splitlines()]
expected_requests = sorted(
    (event for event in events if event['event'] == 'request'),
    key=lambda event: event['reader'],
)
directory = (nullcontext(existing[0]) if existing else
             tempfile.TemporaryDirectory(prefix='rust-compare-', dir=target))
with directory as fixture_dir:
    fixture_dir = Path(fixture_dir)
    if existing:
        tracker_port = urlsplit((fixture_dir / 'announce').read_text().strip()).port
    else:
        tracker_port = free_port()
        subprocess.run([bench, 'fixtures', '--dir', fixture_dir,
                        '--tracker', f'http://127.0.0.1:{tracker_port}/announce'],
                       check=True, timeout=180)
    seed_port = free_port()
    while seed_port == tracker_port:
        seed_port = free_port()
    children = []
    try:
        tracker = subprocess.Popen([bench, 'tracker', '--listen', f'127.0.0.1:{tracker_port}',
                                    '--peer', f'127.0.0.1:{seed_port}'])
        children.append(tracker)
        wait_for_listener(tracker, tracker_port)
        seed_log = output / 'local-seeder.log'
        with seed_log.open('w') as log:
            seed = subprocess.Popen([bench, 'seed', '--dir', fixture_dir,
                                     '--listen', f'127.0.0.1:{seed_port}'],
                                    stdout=log, stderr=subprocess.STDOUT)
        children.append(seed)
        for _ in range(450):
            if seed.poll() is not None:
                raise RuntimeError(f'local seed exited with {seed.returncode}')
            if 'seeding listen=' in seed_log.read_text():
                break
            time.sleep(.2)
        else:
            raise RuntimeError('local seeder did not verify its files')
        for trial in range(1, 4):
            for label, binary in runs[::1 if trial % 2 else -1]:
                stem = f'{label}-{trial}'
                result_path = output / f'{stem}.json'
                with (output / f'{stem}.log').open('w') as log:
                    subprocess.run([bench, 'run', '--trace', trace, '--dir', fixture_dir,
                                    '--torrplay', binary, '--out', result_path,
                                    '--label', f'revision={revisions[label]}', '--label', 'profile=loopback'],
                                   check=True, timeout=140, stderr=log)
                verify_trial(result_path, expected_requests)
                print(f'{stem} complete', flush=True)
    finally:
        for child in reversed(children):
            stop(child, signal.SIGINT)
