# SPDX-FileCopyrightText: 2026 TorrPlay
# SPDX-License-Identifier: MIT

import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

output = Path(__file__).resolve().parent
shared_target = Path(sys.argv[1]).resolve()
with (output.parent / 'source-revisions.tsv').open(newline='') as source:
    revisions = {row['build']: row['commit'] for row in csv.DictReader(source, delimiter='\t')}
checkouts = {'base': revisions['before'], 'candidate': revisions['after']}
for kind, expected in checkouts.items():
    source = output / kind
    revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
    if revision != expected:
        raise RuntimeError(f'{source} is at {revision}, expected {expected}')

for kind, revision in checkouts.items():
    with tempfile.TemporaryDirectory(prefix=f'probe-{kind}-', dir=output) as work:
        source = Path(work) / 'checkout'
        subprocess.run(['git', 'clone', '--quiet', '--shared', '--no-checkout',
                        '--', output / kind, source], check=True)
        subprocess.run(['git', 'checkout', '--quiet', '--detach', revision], cwd=source, check=True)

        engine = source / 'crates/torrplay-engine/src'
        shutil.copy2(output / 'linux-piece-buffer-probe.rs', engine / 'piece_buffer_probe.rs')
        with (engine / 'cache.rs').open('a', encoding='utf-8') as cache:
            cache.write('\n#[cfg(test)]\n#[path = "piece_buffer_probe.rs"]\nmod piece_buffer_probe;\n')

        result = subprocess.check_output(
            ['cargo', 'test', '--locked', '--offline',
             '--target-dir', shared_target / kind, '-p', 'torrplay-engine', '--lib', '--no-run',
             '--message-format=json', '-j', '2'], cwd=source, text=True)
        artifacts = (json.loads(line) for line in result.splitlines())
        executables = [row['executable'] for row in artifacts
                       if row['reason'] == 'compiler-artifact' and row.get('executable')
                       and row['target']['name'] == 'torrplay_engine' and row['profile']['test']]
        assert len(executables) == 1
        exe = output / f'{kind}-probe-test'
        shutil.copy2(executables[0], exe)
        (output / f'{kind}-probe-executable').write_text(str(exe) + '\n')
