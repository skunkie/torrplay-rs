# SPDX-FileCopyrightText: 2026 TorrPlay
# SPDX-License-Identifier: MIT

import csv
import os
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
environment = os.environ.copy()
for name in ('GLIBC_TUNABLES', 'MALLOC_MMAP_THRESHOLD_'):
    environment.pop(name, None)
shared_target = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd() / 'target'
subprocess.run([sys.executable, root/'build-probe.py', shared_target], check=True)
variants = ('base', 'candidate')
with tempfile.TemporaryDirectory(prefix='.probe-replay-', dir=root) as directory:
    pending = Path(directory) / 'probe.csv'
    with pending.open('w', newline='') as measurements:
        writer = csv.writer(measurements)
        writer.writerow(('build', 'trial', 'measurement', 'bytes', 'nanoseconds'))
        for trial in range(1, 6):
            order = variants if trial % 2 else tuple(reversed(variants))
            for variant in order:
                binary = (root / f'{variant}-probe-executable').read_text().strip()
                result = subprocess.check_output(
                    [binary, 'cache::piece_buffer_probe::piece_buffer_probe', '--exact',
                     '--ignored', '--nocapture', '--test-threads=1'],
                    text=True, env=environment, timeout=45)
                rows = [line.split('probe,', 1)[1].split(',') for line in result.splitlines()
                        if 'probe,' in line]
                if len(rows) != 256:
                    raise RuntimeError(f'{variant} probe {trial}: expected 256 rows, got {len(rows)}')
                writer.writerows((variant, trial, *row) for row in rows)
                print(f'{variant} probe {trial} complete', flush=True)
    pending.replace(root / 'probe.csv')
