# SPDX-FileCopyrightText: 2026 TorrPlay
# SPDX-License-Identifier: MIT

import argparse
import hashlib
import http.server
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import threading
import time
import urllib.request

MIB = 1 << 20
ROOT = Path(__file__).resolve().parent


def encode(value):
    if isinstance(value, int):
        return f'i{value}e'.encode()
    if isinstance(value, bytes):
        return str(len(value)).encode() + b':' + value
    return b'd' + b''.join(encode(key) + encode(value[key]) for key in sorted(value)) + b'e'


def port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def stop(process):
    if process.poll() is None:
        process.terminate()
    try:
        process.wait(20)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def run(options):
    seed_port = port()
    compact_peer = socket.inet_aton('127.0.0.1') + struct.pack('!H', seed_port)
    started = time.monotonic()

    class Tracker(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            data = encode({b'interval': 10, b'peers': compact_peer})
            self.send_response(200)
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, fmt, *args):
            pass

    fixtures = ROOT / 'fixtures'
    fixtures.mkdir(exist_ok=True)
    work = ROOT / options.label
    work.mkdir()
    traces = []
    running = []
    phase = 'startup'
    done = threading.Event()
    failures = []
    sampler = None
    tracker = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Tracker)
    tracker_thread = threading.Thread(target=tracker.serve_forever)
    try:
        tracker_thread.start()
        announce = f'http://127.0.0.1:{tracker.server_port}/announce'
        for index, piece_mib in enumerate(options.pieces):
            name = f'fixture-{index}-{piece_mib}m.mkv'
            byte_count = options.transfer * MIB
            with (fixtures / name).open('wb') as file:
                file.truncate(byte_count)
            piece_size = piece_mib * MIB
            assert byte_count % piece_size == 0
            pieces = hashlib.sha1(bytes(piece_size)).digest() * (byte_count // piece_size)
            meta = encode({b'announce': announce.encode(), b'info': {
                b'name': name.encode(), b'length': byte_count, b'piece length': piece_size,
                b'pieces': pieces}})
            path = work / f'{name}.torrent'
            path.write_bytes(meta)
            traces.append(path)
        with (work / 'seeder.log').open('w') as log:
            seeder = subprocess.Popen(['aria2c', '--disable-ipv6=true',
                '--enable-dht=false', '--enable-dht6=false', '--enable-peer-exchange=false',
                '--bt-enable-lpd=false', '--check-integrity=true', '--seed-time=60',
                '--max-concurrent-downloads=12', '--max-overall-upload-limit=160M',
                '--file-allocation=none', f'--listen-port={seed_port}', f'--dir={fixtures}',
                *map(str, traces)], stdout=log, stderr=subprocess.STDOUT)
        running.append(seeder)
        api_port = port()
        base = f'http://127.0.0.1:{api_port}'
        env = os.environ.copy()
        if options.mmap:
            env['GLIBC_TUNABLES'] = 'glibc.malloc.mmap_threshold=131072'
        with (work / 'server.log').open('w') as log:
            server = subprocess.Popen([options.binary, '--data-dir', str(work / 'data'),
                '--listen', f'127.0.0.1:{api_port}', '--peer-port', '0', '--no-dht',
                '--log-level', 'warn'], stdout=log, stderr=subprocess.STDOUT, env=env)
        running.append(server)

        def request(path, method='GET', data=None, headers=None):
            return urllib.request.urlopen(
                urllib.request.Request(base + path, data, headers or {}, method=method), timeout=8)

        for _ in range(120):
            if server.poll() is not None:
                raise RuntimeError(f'server exited {server.returncode}')
            try:
                with request('/readyz'):
                    break
            except OSError:
                time.sleep(0.25)
        else:
            raise RuntimeError('server did not become ready')

        with request('/api/v1/system') as response:
            (work / 'system.json').write_bytes(response.read())
        with request('/api/v1/settings') as response:
            etag = response.headers['ETag']
        with request('/api/v1/settings', 'PATCH', json.dumps({
                'cache_capacity_bytes': options.cache * MIB,
                'background_downloads_enabled': False,
                'idle_reader_timeout_seconds': 0,
                'piece_wait_seconds': 25}).encode(),
                {'If-Match': etag, 'Content-Type': 'application/merge-patch+json'}) as response:
            (work / 'settings.json').write_bytes(response.read())

        def sample():
            try:
                with (work / 'samples.jsonl').open('w', buffering=1) as output:
                    while not done.is_set():
                        now = phase
                        fields = dict(line.split(':', 1) for line in Path(
                            f'/proc/{server.pid}/status').read_text().splitlines() if ':' in line)
                        values = {k: int(fields[k].split()[0]) * 1024
                                  for k in ('VmRSS', 'RssAnon', 'VmHWM', 'VmSwap')}
                        free = int(next(line for line in Path('/proc/meminfo').read_text().splitlines()
                                        if line.startswith('MemAvailable:')).split()[1])
                        if values['VmRSS'] > 1792 * MIB or free < 400 * 1024:
                            server.terminate()
                            raise RuntimeError(f'memory stop at {now}: {values}, {free} KiB available')
                        with request('/api/v1/cache/statistics') as response:
                            cache = json.load(response)
                        output.write(json.dumps({'seconds': round(time.monotonic() - started, 3),
                                                 'phase': now, **values, 'cache': cache}) + '\n')
                        done.wait(.4)
            except Exception as error:
                failures.append(error)
                done.set()

        sampler = threading.Thread(target=sample)
        sampler.start()
        print(f'{options.label}: started', flush=True)
        time.sleep(2)
        boundary = 'torrplay-memory-test'
        for file in traces:
            phase = f'{file.stem}:stream'
            metadata = file.read_bytes()
            payload = (f'--{boundary}\r\nContent-Disposition: form-data; name="metainfo"; '
                       'filename="fixture.torrent"\r\nContent-Type: application/x-bittorrent\r\n\r\n'
                       ).encode() + metadata + f'\r\n--{boundary}--\r\n'.encode()
            with request('/api/v1/torrents', 'POST', payload,
                         {'Content-Type': f'multipart/form-data; boundary={boundary}'}) as response:
                torrent = json.load(response)['links']['self']
            with request(torrent + '/files') as response:
                content = json.load(response)['items'][0]['links']['content']
            started_stream = time.monotonic()
            result = subprocess.run(['curl', '--silent', '--show-error', '--fail',
                '--output', os.devnull, '--write-out', '%{size_download}', '--max-time', '150',
                base + content], check=True, capture_output=True)
            assert int(result.stdout) == options.transfer * MIB, result.stdout
            print(f'{options.label}: {phase} {options.transfer} MiB '
                  f'in {time.monotonic() - started_stream:.1f}s', flush=True)
            phase = f'{file.stem}:held'
            time.sleep(2)
            with request(torrent, 'DELETE'):
                pass
            phase = f'{file.stem}:deleted'
            time.sleep(3)
            if failures:
                raise failures[0]
        phase = 'idle'
        time.sleep(8)
        if failures:
            raise failures[0]
    finally:
        done.set()
        if sampler:
            sampler.join()
        for process in reversed(running):
            stop(process)
        if tracker_thread.ident is not None:
            tracker.shutdown()
            tracker_thread.join()
        tracker.server_close()
    print(f'{options.label}: finished', flush=True)


parser = argparse.ArgumentParser()
parser.add_argument('binary')
parser.add_argument('label')
parser.add_argument('--cache', type=int, default=1024)
parser.add_argument('--transfer', type=int, default=1280)
parser.add_argument('--pieces', type=int, nargs='+', default=[1, 16, 2, 8])
parser.add_argument('--mmap', action='store_true')
run(parser.parse_args())
