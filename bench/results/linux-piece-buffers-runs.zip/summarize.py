# SPDX-FileCopyrightText: 2026 TorrPlay
# SPDX-License-Identifier: MIT

from collections import defaultdict
import json
from pathlib import Path
import sys

MIB = 1 << 20

for name in sys.argv[1:]:
    root = Path(name)
    system = json.loads((root / 'system.json').read_text())
    print(f"{root.name} | {system['architecture']} | {system['version']} | {system['commit']}")
    rows = defaultdict(list)
    for line in (root / 'samples.jsonl').read_text().splitlines():
        sample = json.loads(line)
        rows[sample['phase']].append(sample)
    print('Memory figures are in MiB.')
    columns = ('peak sampled RSS', 'peak sampled anon RSS', 'last RSS', 'last anon RSS',
               'cache max', 'cache end')
    print(f"{'phase':25} " + ' '.join(f'{label:>{max(9, len(label))}}' for label in columns)
          + f" {'evictions':>11}")
    for phase, samples in rows.items():
        last = samples[-1]
        peak = [max(s[key] for s in samples) for key in ('VmRSS', 'RssAnon')]
        cache = [s['cache']['usage_bytes'] for s in samples]
        values = peak + [last['VmRSS'], last['RssAnon'], max(cache), cache[-1]]
        sizes = ' '.join(f'{value / MIB:{max(9, len(label))}.1f}'
                         for value, label in zip(values, columns))
        print(f"{phase:25} {sizes} {last['cache']['eviction_count']:11,}")
    print()
