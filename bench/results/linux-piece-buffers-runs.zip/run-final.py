# SPDX-FileCopyrightText: 2026 TorrPlay
# SPDX-License-Identifier: MIT

import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
target, before, after = (Path(arg).resolve() for arg in sys.argv[1:])
environment = os.environ.copy()
for key in ('GLIBC_TUNABLES', 'MALLOC_MMAP_THRESHOLD_'):
    environment.pop(key, None)
subprocess.run([sys.executable, root/'compare-rust.py', target, before, after],
               env=environment, check=True)
for binary, label in ((before, 'before-memory'), (after, 'after-memory')):
    subprocess.run([sys.executable, root/'run.py', binary, label], env=environment, check=True)
